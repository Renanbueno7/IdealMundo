# DealWorld - E-commerce Platform

DealWorld é uma plataforma de e-commerce moderna desenvolvida com React e TypeScript, oferecendo uma experiência de compra similar à Shopee.

![DealWorld Screenshot](https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&w=1200&h=630)

## 🚀 Funcionalidades

- ✨ Interface moderna e responsiva
- 🛍️ Mais de 200 produtos em diferentes categorias
- 🔍 Sistema de busca de produtos
- 🏷️ Sistema de descontos
- ⭐ Avaliações de produtos
- 🛒 Carrinho de compras
- 📱 Design mobile-first

## 🛠️ Tecnologias Utilizadas

- React 18
- TypeScript
- Tailwind CSS
- Vite
- Lucide React (ícones)

## 📦 Instalação

```bash
# Clone o repositório
git clone https://github.com/seu-usuario/dealworld.git

# Entre no diretório
cd dealworld

# Instale as dependências
npm install

# Inicie o servidor de desenvolvimento
npm run dev
```

## 🖥️ Ambiente de Desenvolvimento

- Node.js >= 18
- npm >= 9

## 📝 Scripts Disponíveis

- `npm run dev` - Inicia o servidor de desenvolvimento
- `npm run build` - Cria a build de produção
- `npm run preview` - Visualiza a build de produção localmente

## 📱 Screenshots

### Desktop
![Desktop View](https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&h=630)

### Mobile
![Mobile View](https://images.unsplash.com/photo-1522204523234-8729aa6e3d5f?auto=format&fit=crop&w=600&h=900)

## 🤝 Contribuindo

Contribuições são sempre bem-vindas! Por favor, leia o guia de contribuição antes de enviar um pull request.

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.