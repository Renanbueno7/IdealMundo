export const categories = [
  'Eletrônicos',
  'Moda',
  'Casa e Decoração',
  'Beleza e Cuidados Pessoais',
  'Esportes',
  'Acessórios',
  'Informática',
  'Brinquedos',
  'Livros',
  'Saúde',
  'Pet Shop',
  'Automotivo'
] as const;

export type CategoryType = typeof categories[number];