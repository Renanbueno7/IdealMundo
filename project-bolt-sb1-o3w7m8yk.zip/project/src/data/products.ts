import { Product } from '../types/product';
import { generateProducts } from '../utils/productGenerator';

export const products: Product[] = generateProducts();