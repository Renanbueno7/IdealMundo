import { Product } from '../types/product';
import { categories } from '../data/categories';

const generateRandomPrice = (min: number, max: number): number => {
  return Number((Math.random() * (max - min) + min).toFixed(2));
};

const generateRandomRating = (): number => {
  return Number((Math.random() * (5 - 3.5) + 3.5).toFixed(1));
};

const generateRandomSales = (): number => {
  return Math.floor(Math.random() * 10000);
};

const generateRandomStock = (): number => {
  return Math.floor(Math.random() * 1000) + 50;
};

const generateRandomDiscount = (): number | undefined => {
  return Math.random() > 0.7 ? Math.floor(Math.random() * 50) + 10 : undefined;
};

const productTemplates = [
  // Eletrônicos
  {
    names: [
      'Smartphone Samsung Galaxy A54',
      'iPhone 15 Pro Max',
      'Fone de Ouvido Bluetooth TWS',
      'Smart TV LED 55" 4K',
      'Notebook Dell Inspiron',
      'Tablet Samsung Galaxy Tab S9',
      'Console PlayStation 5',
      'Xbox Series X',
      'Câmera Digital Sony',
      'Smartwatch Apple Watch',
    ],
    category: 'Eletrônicos',
    priceRange: { min: 299, max: 8999 },
    images: [
      'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9',
      'https://images.unsplash.com/photo-1546868871-7041f2a55e12',
    ]
  },
  // Moda
  {
    names: [
      'Tênis Nike Air Max',
      'Bolsa de Couro Feminina',
      'Camisa Social Masculina',
      'Vestido Floral Midi',
      'Calça Jeans Skinny',
      'Blazer Feminino',
      'Sapato Social Masculino',
      'Óculos de Sol Ray-Ban',
    ],
    category: 'Moda',
    priceRange: { min: 79, max: 599 },
    images: [
      'https://images.unsplash.com/photo-1560769629-975ec94e6a86',
      'https://images.unsplash.com/photo-1544441893-675973e31985',
    ]
  },
  // Casa e Decoração
  {
    names: [
      'Jogo de Panelas Antiaderente',
      'Kit Organizador de Gavetas',
      'Luminária de Mesa LED',
      'Conjunto de Pratos Porcelana',
      'Tapete Sala de Estar',
      'Cortina Blackout',
      'Almofadas Decorativas',
    ],
    category: 'Casa e Decoração',
    priceRange: { min: 49, max: 899 },
    images: [
      'https://images.unsplash.com/photo-1538688525198-9b88f6f53126',
      'https://images.unsplash.com/photo-1513161455079-7dc1de15ef3e',
    ]
  },
  // Continue with more categories...
];

export const generateProducts = (): Product[] => {
  const products: Product[] = [];
  const totalProducts = 250;

  for (let i = 0; i < totalProducts; i++) {
    const template = productTemplates[Math.floor(Math.random() * productTemplates.length)];
    const name = template.names[Math.floor(Math.random() * template.names.length)];
    const price = generateRandomPrice(template.priceRange.min, template.priceRange.max);
    const discount = generateRandomDiscount();
    const oldPrice = discount ? price * (1 + discount / 100) : undefined;

    products.push({
      id: `${i + 1}`,
      name,
      price,
      oldPrice,
      discount,
      description: `${name} - Produto de alta qualidade com garantia e entrega rápida`,
      image: template.images[Math.floor(Math.random() * template.images.length)],
      category: template.category,
      rating: generateRandomRating(),
      stock: generateRandomStock(),
      sales: generateRandomSales(),
    });
  }

  return products;
};